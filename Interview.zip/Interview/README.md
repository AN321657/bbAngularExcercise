# weather-report

This project is generated with [yo angular generator] 

## Build & development

Run `grunt` for building and `grunt serve` for preview.

## Testing

Running `grunt test` will run the unit tests with karma.

Additional e2e test is will run with protractor.


